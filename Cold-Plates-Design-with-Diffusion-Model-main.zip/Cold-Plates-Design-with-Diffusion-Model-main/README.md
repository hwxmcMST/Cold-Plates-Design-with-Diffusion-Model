# Cold-Plates-Design-with-Diffusion-Model
Optimization of Cold Plates with Asymmetric Heat Sources via a Diffusion-Model–Driven Digital Twin

# Overview
This study developed a diffusion model–driven digital twin framework that integrates physics-based multi-objective topology optimization and generative AI (diffusion model) for the design of liquid-cooled cold plates under non-uniform heat flux conditions. By blending the predictive power of physics-based methods with the efficiency of generative AI, the framework enables rapid exploration and generation of physically consistent geometries, effectively transferring high-fidelity predictive capabilities from the designer’s supercomputer to the operational environment through the digital twin, while markedly reducing computational costs.

![Overview of the Process](Overview_Digital%20Twin.png)





# 📄 Citation
If you use this code, please cite:

Wu, H., Coaty, J., Zong, Y., Azar, K., Minary-Jolandan, M., Tian, Z., & Xu, Y. (2026). Optimization of cold plates with asymmetric heat sources via a diffusion-model-driven digital twin. Structural and Multidisciplinary Optimization, 69(4), 85. 
